<!DOCTYPE html>
<html>
	<head>
			<meta charset="utf-8"/>
			<title>Weterynarz</title>
			<link rel="stylesheet" href="weterynarz.css"/>
	</head>
	<body>
		<section id="baner">
			<h1>Gabinet weterynaryjny</h1>
		</section>
		<section id="lewy">
			<h2>Psy</h2>
			<?php include "skrypt1.php"; ?>
			<h2>koty</h2>
			<p>wynik zapytania 2</p>
		</section>
		<section id="srodkowy">
			<h2>Szczegółowa informacja o zwierzętach</h2>
			<p>wynik zapytania 3</p>
		</section>
		<section id="prawy">
			<h2>Weterynarz</h2>
			
			<a href="logo.jpg"><img src="logo-mini.jpg" alt=""/></a>
			<p>Krzystof Nowakowski, lekarz weterynarii</p>
			<h2>Godziny przyjęć</h2>
			<table>
				<tr>
					<td>Poniedziałek</td>
					<td>15:00-19:00</td>
				</tr>
				<tr>
					<td>Wtorek</td>
					<td>15:00-19:00</td>
				</tr>
			</table>
		</section>
	</body>
</html>