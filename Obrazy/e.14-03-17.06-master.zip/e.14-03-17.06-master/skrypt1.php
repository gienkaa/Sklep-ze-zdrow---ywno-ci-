<?php
	$db = mysqli_connect('localhost', 'root', '', 'weterynarz');
	
	$query = mysqli_query($db, "SELECT `id`, `imie`, `wlasciciel` FROM `zwierzeta` WHERE `rodzaj`=1;");

	while($row=mysqli_fetch_array($query)) {
		echo "<p>{$row[0]}, {$row[1]}, {$row[2]}</p>";
	}
	mysqli_close($db);